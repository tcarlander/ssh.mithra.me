Within this directory, should live all the .htc and .xbl files that are associated with our scripted implementations of standards.

The files here should be as thin as possible, with the actual behaviour coming from javaScript objects defined in the .js files located in ../lib/*.

